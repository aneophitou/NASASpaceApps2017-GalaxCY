x = [35.030972 35.030972];
y = [32.316654 32.324445];
dlmwrite('forx.csv', y,'precision','%.6f');
dlmwrite('fory.csv', x,'precision','%.6f');